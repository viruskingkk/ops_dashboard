#!/usr/bin/env bash
# =============================================================================
# Ansible DB Proxy 初始化安裝腳本
# 在「可連到所有 DB 的跳板機」上執行
# 支援：Ubuntu 20.04/22.04、Debian 11/12、CentOS/RHEL 8+
# =============================================================================
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
log()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
err()  { echo -e "${RED}[ERR ]${NC} $*"; exit 1; }

ANSIBLE_USER="${ANSIBLE_USER:-ansible}"
INSTALL_DIR="${INSTALL_DIR:-/opt/ansible-deploy}"

# --------------------------------------------------------------------------- #
# 1. 偵測 OS
# --------------------------------------------------------------------------- #
detect_os() {
  if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_ID="${ID}"
    OS_VER="${VERSION_ID%%.*}"
  else
    err "無法偵測作業系統，請確認為 Ubuntu/Debian/CentOS/RHEL"
  fi
  log "偵測到系統：${PRETTY_NAME}"
}

# --------------------------------------------------------------------------- #
# 2-a. 安裝 mysql-client（跨發行版）
# --------------------------------------------------------------------------- #
install_mysql_client() {
  log "安裝 mysql-client..."

  # 先嘗試系統 repo 內的常見套件名
  for PKG in mysql mysql-community-client mariadb mariadb-client; do
    if dnf install -y --quiet "${PKG}" 2>/dev/null; then
      log "mysql-client 已透過系統 repo 安裝（${PKG}）"
      return 0
    fi
  done

  # 系統 repo 無法安裝 → 加入 MySQL 官方 repo
  warn "系統 repo 無 mysql-client，改從 MySQL 官方 repo 安裝..."

  local MAJOR_VER="${OS_VER}"
  local RPM_URL=""

  case "${OS_ID}" in
    centos|rhel|rocky|almalinux)
      # CentOS Stream 10 / RHEL 10 → el9 RPM 目前相容
      if [ "${MAJOR_VER}" -ge 10 ] 2>/dev/null; then
        RPM_URL="https://dev.mysql.com/get/mysql80-community-release-el9-1.noarch.rpm"
      elif [ "${MAJOR_VER}" -ge 9 ] 2>/dev/null; then
        RPM_URL="https://dev.mysql.com/get/mysql80-community-release-el9-1.noarch.rpm"
      else
        RPM_URL="https://dev.mysql.com/get/mysql80-community-release-el8-1.noarch.rpm"
      fi
      ;;
  esac

  if [ -n "${RPM_URL}" ]; then
    log "下載 MySQL repo RPM：${RPM_URL}"
    dnf install -y "${RPM_URL}" 2>/dev/null || rpm -ivh "${RPM_URL}"

    # 停用 mysql-8.4（預設）改用 8.0 LTS client；若失敗就直接裝
    dnf config-manager --disable mysql-8.4-lts-community 2>/dev/null || true
    dnf config-manager --enable mysql80-community 2>/dev/null || true

    if dnf install -y mysql-community-client; then
      log "mysql-community-client 安裝成功 ✓"
      return 0
    fi
  fi

  # 最後備案：安裝 mariadb（完全相容 mysql-client CLI）
  warn "MySQL 官方 client 安裝失敗，改用 mariadb（CLI 完全相容）..."
  if dnf install -y mariadb 2>/dev/null || dnf install -y mariadb-client 2>/dev/null; then
    log "mariadb（mysql-client 相容）安裝成功 ✓"
    # 建立 mysql symlink（若不存在）
    if ! command -v mysql &>/dev/null; then
      ln -sf "$(command -v mariadb)" /usr/local/bin/mysql 2>/dev/null || true
    fi
    return 0
  fi

  err "無法安裝 mysql-client，請手動執行：dnf install mariadb 或 mysql-community-client"
}

# --------------------------------------------------------------------------- #
# 2. 安裝系統套件
# --------------------------------------------------------------------------- #
install_packages() {
  log "安裝必要套件..."
  case "${OS_ID}" in
    ubuntu|debian)
      export DEBIAN_FRONTEND=noninteractive
      apt-get update -qq
      apt-get install -y -qq \
        python3 python3-pip python3-venv \
        mysql-client \
        git curl wget jq \
        sshpass openssh-client
      ;;
    centos|rhel|rocky|almalinux)
      dnf install -y epel-release 2>/dev/null || yum install -y epel-release 2>/dev/null

      # 安裝基本工具
      dnf install -y \
        python3 python3-pip \
        git curl wget jq \
        sshpass openssh-clients

      # 安裝 mysql-client：
      # CentOS Stream 10 / RHEL 10 官方 repo 已無 mysql 套件，改從 MySQL 官方 repo 安裝
      install_mysql_client
      ;;
    *)
      err "不支援的 OS：${OS_ID}"
      ;;
  esac
}

# --------------------------------------------------------------------------- #
# 3. 建立 Python venv + 安裝 Ansible 與 MySQL 驅動
# --------------------------------------------------------------------------- #
install_ansible() {
  log "建立 Python 虛擬環境於 ${INSTALL_DIR}/venv ..."
  mkdir -p "${INSTALL_DIR}"
  python3 -m venv "${INSTALL_DIR}/venv"
  source "${INSTALL_DIR}/venv/bin/activate"

  log "升級 pip..."
  pip install --upgrade pip -q

  log "安裝 Ansible + community.mysql + PyMySQL..."
  pip install -q \
    ansible-core>=2.15 \
    "ansible>=8.0" \
    PyMySQL \
    cryptography \
    requests

  log "安裝 Ansible Galaxy collection..."
  ansible-galaxy collection install community.mysql --upgrade
  ansible-galaxy collection install community.general --upgrade

  deactivate
  log "Ansible 安裝完成：$(${INSTALL_DIR}/venv/bin/ansible --version | head -1)"
}

# --------------------------------------------------------------------------- #
# 4. 建立目錄與設定檔
# --------------------------------------------------------------------------- #
setup_directories() {
  log "建立工作目錄結構..."
  mkdir -p "${INSTALL_DIR}"/{inventories,playbooks,roles,group_vars,logs,sql_tmp}
  chmod 750 "${INSTALL_DIR}"
  chmod 700 "${INSTALL_DIR}/sql_tmp"   # SQL 暫存目錄僅 owner 可讀

  # ansible.cfg
  cat > "${INSTALL_DIR}/ansible.cfg" <<'EOF'
[defaults]
inventory          = inventories/hosts.ini
roles_path         = roles
log_path           = logs/ansible.log
host_key_checking  = False
stdout_callback    = yaml
gathering          = smart
fact_caching       = jsonfile
fact_caching_connection = /tmp/ansible_facts_cache
fact_caching_timeout = 3600
retry_files_enabled = False

[ssh_connection]
pipelining = True
ssh_args   = -o ControlMaster=auto -o ControlPersist=60s -o StrictHostKeyChecking=no
EOF

  log "ansible.cfg 已寫入 ${INSTALL_DIR}/ansible.cfg"
}

# --------------------------------------------------------------------------- #
# 5. 寫入 inventory
# --------------------------------------------------------------------------- #
setup_inventory() {
  log "建立 inventory..."
  cat > "${INSTALL_DIR}/inventories/hosts.ini" <<'EOF'
# 本機作為 DB proxy（所有 SQL 由此機器透過 mysql-client 直連 TiDB）
[db_proxy]
localhost ansible_connection=local

[db_proxy:vars]
ansible_python_interpreter=/opt/ansible-deploy/venv/bin/python3
EOF
}

# --------------------------------------------------------------------------- #
# 6. 寫入 group_vars（DB 連線資訊）
# --------------------------------------------------------------------------- #
setup_group_vars() {
  log "建立 group_vars/all.yml（含 TiDB 連線資訊）..."
  cat > "${INSTALL_DIR}/group_vars/all.yml" <<'EOF'
---
# =============================================================================
# TiDB 連線設定
# 密碼建議改用 ansible-vault 加密：
#   ansible-vault encrypt_string '^PwdOfDev2020$' --name 'uat_password'
# =============================================================================

tidb_connections:
  uat_pp:
    host:     "dev-to-tidb-backend.reelx.fun"
    port:     30040
    user:     "root"
    password: "^PwdOfDev2020$"
    label:    "UAT-PP"

  uat_game:
    host:     "dev-to-tidb-game.reelx.fun"
    port:     30020
    user:     "root"
    password: "^PwdOfDev2020$"
    label:    "UAT-Game"

  prod_pp:
    host:     "prod-to-tidb-backend.reelx.fun"
    port:     30040
    user:     "root"
    password: "^PwdOfProd2025$"
    label:    "PROD-PP"

  prod_game:
    host:     "prod-to-tidb-game.reelx.fun"
    port:     30020
    user:     "root"
    password: "^PwdOfProd2025$"
    label:    "PROD-Game"

# SQL 執行結果輸出目錄（跳板機本地路徑）
sql_output_dir: "/opt/ansible-deploy/logs/sql_results"

# 每次 SQL 執行 timeout（秒）
sql_timeout: 60
EOF
}

# --------------------------------------------------------------------------- #
# 7. 建立 tidb_query role
# --------------------------------------------------------------------------- #
setup_role() {
  log "建立 tidb_query role..."
  mkdir -p "${INSTALL_DIR}/roles/tidb_query/tasks"
  mkdir -p "${INSTALL_DIR}/roles/tidb_query/templates"

  # tasks/main.yml
  cat > "${INSTALL_DIR}/roles/tidb_query/tasks/main.yml" <<'ROLE_EOF'
---
# tidb_query role — 透過 mysql-client CLI 執行 SQL 並回傳結果
# 呼叫方式（在 playbook 中）：
#   vars:
#     tidb_env: "uat_pp"          # 對應 group_vars tidb_connections key
#     tidb_database: "backend"    # 資料庫名稱（可留空）
#     tidb_sql: "SELECT 1;"       # 要執行的 SQL
#     tidb_output_format: "table" # table | json | csv

- name: "設定連線變數"
  ansible.builtin.set_fact:
    _conn: "{{ tidb_connections[tidb_env] }}"
    _ts:   "{{ lookup('pipe', 'date +%Y%m%d_%H%M%S') }}"

- name: "確認輸出目錄存在"
  ansible.builtin.file:
    path: "{{ sql_output_dir }}"
    state: directory
    mode: '0750'

- name: "將 SQL 寫入暫存檔"
  ansible.builtin.copy:
    content: "{{ tidb_sql }}"
    dest:    "/opt/ansible-deploy/sql_tmp/query_{{ _ts }}.sql"
    mode:    '0600'

- name: "執行 SQL（mysql-client）"
  ansible.builtin.shell: |
    mysql \
      -h "{{ _conn.host }}" \
      -P "{{ _conn.port }}" \
      -u "{{ _conn.user }}" \
      -p"{{ _conn.password }}" \
      {% if tidb_database is defined and tidb_database != '' %}"{{ tidb_database }}"{% endif %} \
      {% if tidb_output_format | default('table') == 'json' %}--json{% endif %} \
      {% if tidb_output_format | default('table') == 'csv' %}--batch --silent{% endif %} \
      --connect-timeout=10 \
      -e "{{ tidb_sql }}" \
      2>&1
  register: sql_result
  no_log: true     # 不在 log 中暴露密碼
  timeout: "{{ sql_timeout | int }}"
  ignore_errors: true

- name: "儲存執行結果"
  ansible.builtin.copy:
    content: |
      === TiDB Query Result ===
      環境   : {{ _conn.label }}
      主機   : {{ _conn.host }}:{{ _conn.port }}
      資料庫 : {{ tidb_database | default('(未指定)') }}
      時間   : {{ _ts }}
      格式   : {{ tidb_output_format | default('table') }}
      SQL    :
      {{ tidb_sql }}
      --- 結果 ---
      {{ sql_result.stdout }}
      {% if sql_result.rc != 0 %}
      --- 錯誤 ---
      {{ sql_result.stderr }}
      {% endif %}
    dest: "{{ sql_output_dir }}/result_{{ _ts }}.txt"
    mode: '0640'

- name: "清除暫存 SQL 檔"
  ansible.builtin.file:
    path: "/opt/ansible-deploy/sql_tmp/query_{{ _ts }}.sql"
    state: absent

- name: "回傳查詢結果（stdout）"
  ansible.builtin.debug:
    msg: "{{ sql_result.stdout_lines }}"

- name: "失敗時顯示錯誤"
  ansible.builtin.fail:
    msg: "SQL 執行失敗：{{ sql_result.stderr }}"
  when: sql_result.rc != 0
ROLE_EOF

  # tasks: 快速連線測試
  cat > "${INSTALL_DIR}/roles/tidb_query/tasks/ping.yml" <<'PING_EOF'
---
- name: "測試所有 TiDB 連線"
  ansible.builtin.shell: |
    mysql \
      -h "{{ item.value.host }}" \
      -P "{{ item.value.port }}" \
      -u "{{ item.value.user }}" \
      -p"{{ item.value.password }}" \
      --connect-timeout=5 \
      -e "SELECT 'OK' AS status, VERSION() AS version;" \
      2>&1
  loop: "{{ tidb_connections | dict2items }}"
  loop_control:
    label: "{{ item.value.label }}"
  register: ping_results
  ignore_errors: true
  no_log: true

- name: "顯示連線測試結果"
  ansible.builtin.debug:
    msg: >
      [{{ item.item.value.label }}]
      {{ '✅ OK' if item.rc == 0 else '❌ FAIL' }}
      {{ item.stdout if item.rc == 0 else item.stderr }}
  loop: "{{ ping_results.results }}"
  loop_control:
    label: "{{ item.item.value.label }}"
PING_EOF
}

# --------------------------------------------------------------------------- #
# 8. 建立 Playbook
# --------------------------------------------------------------------------- #
setup_playbooks() {
  log "建立 Playbooks..."

  # 主查詢 playbook（由 Web UI 呼叫）
  cat > "${INSTALL_DIR}/playbooks/run_sql.yml" <<'PB_EOF'
---
# =============================================================================
# run_sql.yml — 執行單次 SQL 查詢
# 呼叫範例：
#   ansible-playbook playbooks/run_sql.yml \
#     -e "tidb_env=uat_pp" \
#     -e "tidb_database=backend" \
#     -e "tidb_sql='SELECT * FROM users LIMIT 10;'" \
#     -e "tidb_output_format=table"
# =============================================================================
- name: "TiDB SQL 執行"
  hosts: db_proxy
  gather_facts: false
  vars:
    tidb_env:           "{{ tidb_env           | default('uat_pp') }}"
    tidb_database:      "{{ tidb_database      | default('') }}"
    tidb_sql:           "{{ tidb_sql           | mandatory }}"
    tidb_output_format: "{{ tidb_output_format | default('table') }}"

  pre_tasks:
    - name: "驗證 tidb_env 合法"
      ansible.builtin.assert:
        that: tidb_env in tidb_connections
        fail_msg: "tidb_env '{{ tidb_env }}' 不在設定清單中。可用：{{ tidb_connections.keys() | list }}"

  roles:
    - tidb_query
PB_EOF

  # 連線測試 playbook
  cat > "${INSTALL_DIR}/playbooks/ping_all.yml" <<'PING_PB_EOF'
---
# =============================================================================
# ping_all.yml — 測試所有 TiDB 連線是否正常
# 呼叫：ansible-playbook playbooks/ping_all.yml
# =============================================================================
- name: "TiDB 全連線測試"
  hosts: db_proxy
  gather_facts: false
  tasks:
    - name: "include ping tasks"
      ansible.builtin.include_tasks:
        file: "{{ playbook_dir }}/../roles/tidb_query/tasks/ping.yml"
PING_PB_EOF

  # 批次 SQL 執行 playbook（支援多筆）
  cat > "${INSTALL_DIR}/playbooks/run_sql_batch.yml" <<'BATCH_PB_EOF'
---
# =============================================================================
# run_sql_batch.yml — 批次執行 SQL 清單
# 呼叫範例：
#   ansible-playbook playbooks/run_sql_batch.yml \
#     -e "tidb_env=prod_pp" \
#     -e "tidb_database=backend" \
#     -e @/path/to/batch.yml
#
# batch.yml 格式：
#   sql_list:
#     - "ALTER TABLE users ADD COLUMN xxx INT;"
#     - "UPDATE config SET val='yyy' WHERE key='zzz';"
# =============================================================================
- name: "TiDB 批次 SQL 執行"
  hosts: db_proxy
  gather_facts: false
  vars:
    tidb_env:      "{{ tidb_env | default('uat_pp') }}"
    tidb_database: "{{ tidb_database | default('') }}"
    sql_list:      "{{ sql_list | mandatory }}"

  pre_tasks:
    - name: "驗證 tidb_env 合法"
      ansible.builtin.assert:
        that: tidb_env in tidb_connections
        fail_msg: "tidb_env '{{ tidb_env }}' 不合法"

  tasks:
    - name: "逐筆執行 SQL"
      ansible.builtin.include_role:
        name: tidb_query
      vars:
        tidb_sql: "{{ item }}"
      loop: "{{ sql_list }}"
      loop_control:
        label: "{{ item | truncate(60) }}"
BATCH_PB_EOF
}

# --------------------------------------------------------------------------- #
# 9. 建立 wrapper script（供 Web UI 呼叫）
# --------------------------------------------------------------------------- #
setup_wrapper() {
  log "建立 wrapper 執行腳本..."
  cat > "${INSTALL_DIR}/run_query.sh" <<'WRAP_EOF'
#!/usr/bin/env bash
# =============================================================================
# run_query.sh — Web UI 呼叫的 wrapper
# 用法：./run_query.sh <env> <database> <sql> [format]
#   env      : uat_pp | uat_game | prod_pp | prod_game
#   database : 資料庫名稱（可留空 ""）
#   sql      : SQL 字串
#   format   : table（預設）| json | csv
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/venv/bin/activate"

TIDB_ENV="${1:?需要指定 env (uat_pp/uat_game/prod_pp/prod_game)}"
TIDB_DB="${2:-}"
TIDB_SQL="${3:?需要指定 SQL}"
TIDB_FMT="${4:-table}"

cd "${SCRIPT_DIR}"
ansible-playbook playbooks/run_sql.yml \
  -e "tidb_env=${TIDB_ENV}" \
  -e "tidb_database=${TIDB_DB}" \
  -e "tidb_output_format=${TIDB_FMT}" \
  -e "tidb_sql=${TIDB_SQL}" \
  2>&1
WRAP_EOF
  chmod +x "${INSTALL_DIR}/run_query.sh"

  # Vault 初始化說明
  cat > "${INSTALL_DIR}/VAULT_SETUP.md" <<'VAULT_EOF'
# Ansible Vault 加密密碼（建議設定）

## 1. 加密 group_vars/all.yml 中的密碼欄位

```bash
cd /opt/ansible-deploy
source venv/bin/activate

# 將整個 all.yml 加密
ansible-vault encrypt group_vars/all.yml

# 或只加密特定值（插入 all.yml 中替換明文）
ansible-vault encrypt_string '^PwdOfDev2020$' --name 'password'
ansible-vault encrypt_string '^PwdOfProd2025$' --name 'password'
```

## 2. 執行時帶入 vault 密碼

```bash
# 互動式輸入
ansible-playbook playbooks/run_sql.yml --ask-vault-pass -e ...

# 或使用密碼檔（chmod 600）
echo "your_vault_pass" > ~/.ansible_vault_pass
chmod 600 ~/.ansible_vault_pass
ansible-playbook playbooks/run_sql.yml --vault-password-file ~/.ansible_vault_pass -e ...
```
VAULT_EOF
}

# --------------------------------------------------------------------------- #
# 10. 驗證安裝
# --------------------------------------------------------------------------- #
verify_install() {
  log "驗證安裝..."
  source "${INSTALL_DIR}/venv/bin/activate"
  cd "${INSTALL_DIR}"

  ansible --version | head -1
  python3 -c "import pymysql; print('PyMySQL OK:', pymysql.__version__)"
  ansible-galaxy collection list community.mysql | grep -i mysql || true

  deactivate
  log "✅ 安裝完成！"
  echo ""
  echo "========================================================"
  echo "  安裝路徑：${INSTALL_DIR}"
  echo "  測試連線：cd ${INSTALL_DIR} && source venv/bin/activate"
  echo "            ansible-playbook playbooks/ping_all.yml"
  echo "  執行 SQL：./run_query.sh uat_pp backend 'SELECT 1;'"
  echo "========================================================"
}

# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
main() {
  [ "$(id -u)" -eq 0 ] || err "請以 root 或 sudo 執行此腳本"
  detect_os
  install_packages
  install_ansible
  setup_directories
  setup_inventory
  setup_group_vars
  setup_role
  setup_playbooks
  setup_wrapper
  verify_install
}

main "$@"