#!/usr/bin/env python3
"""
api_bridge.py — 在跳板機上執行的輕量 HTTP API
Web UI 透過此 API 發送 SQL → 由本機 ansible-playbook 執行 → 回傳結果

啟動：python3 api_bridge.py
預設 port：8765（僅監聽 localhost，需透過 SSH Tunnel 或 Nginx 反代）

安裝依賴：pip install flask
"""

import subprocess, json, os, threading, uuid, time, logging
from flask import Flask, request, jsonify
from datetime import datetime
from pathlib import Path
from functools import wraps

# ─── 設定 ───────────────────────────────────────────────────────────────────
INSTALL_DIR  = Path("/opt/ansible-deploy")
VENV_ANSIBLE = INSTALL_DIR / "venv/bin/ansible-playbook"
LOG_DIR      = INSTALL_DIR / "logs"
API_TOKEN    = os.environ.get("API_BRIDGE_TOKEN", "change-me-in-production")
MAX_JOBS     = 10          # 同時最多執行幾個 job
JOB_TTL      = 3600        # job 結果保留秒數

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "api_bridge.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger(__name__)

app = Flask(__name__)

# ─── Job 狀態儲存（記憶體，重啟清空）────────────────────────────────────────
jobs: dict[str, dict] = {}
jobs_lock = threading.Lock()

# ─── Auth decorator ──────────────────────────────────────────────────────────
def require_token(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get("X-API-Token", "")
        if token != API_TOKEN:
            return jsonify({"error": "Unauthorized"}), 401
        return f(*args, **kwargs)
    return decorated

# ─── Helpers ─────────────────────────────────────────────────────────────────
VALID_ENVS = {"uat_pp", "uat_game", "prod_pp", "prod_game"}

def run_ansible(job_id: str, env: str, database: str, sql: str, fmt: str):
    """背景執行 ansible-playbook，結果寫入 jobs dict"""
    with jobs_lock:
        jobs[job_id]["status"] = "running"
        jobs[job_id]["started_at"] = datetime.utcnow().isoformat()

    try:
        cmd = [
            str(VENV_ANSIBLE),
            str(INSTALL_DIR / "playbooks/run_sql.yml"),
            "-e", f"tidb_env={env}",
            "-e", f"tidb_database={database}",
            "-e", f"tidb_output_format={fmt}",
            "-e", f"tidb_sql={sql}",
        ]
        log.info(f"[{job_id}] 執行 env={env} db={database} fmt={fmt}")
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=str(INSTALL_DIR),
            timeout=120,
        )
        with jobs_lock:
            jobs[job_id].update({
                "status":       "done" if result.returncode == 0 else "error",
                "returncode":   result.returncode,
                "stdout":       result.stdout,
                "stderr":       result.stderr,
                "finished_at":  datetime.utcnow().isoformat(),
            })
    except subprocess.TimeoutExpired:
        with jobs_lock:
            jobs[job_id].update({"status": "timeout", "finished_at": datetime.utcnow().isoformat()})
    except Exception as e:
        with jobs_lock:
            jobs[job_id].update({"status": "error", "stderr": str(e), "finished_at": datetime.utcnow().isoformat()})

def cleanup_old_jobs():
    """定期清理過期 job"""
    while True:
        time.sleep(300)
        now = time.time()
        with jobs_lock:
            expired = [
                jid for jid, j in jobs.items()
                if j.get("status") in ("done", "error", "timeout")
                and (now - j.get("created_epoch", now)) > JOB_TTL
            ]
            for jid in expired:
                del jobs[jid]
                log.info(f"清理過期 job: {jid}")

# ─── Routes ──────────────────────────────────────────────────────────────────

@app.route("/health")
def health():
    return jsonify({"status": "ok", "time": datetime.utcnow().isoformat()})


@app.route("/api/sql/run", methods=["POST"])
@require_token
def run_sql():
    """
    POST /api/sql/run
    Body (JSON):
      { "env": "uat_pp", "database": "backend", "sql": "SELECT 1;", "format": "table" }
    Response:
      { "job_id": "...", "status": "queued" }
    """
    data    = request.get_json(force=True) or {}
    env     = data.get("env", "")
    sql     = data.get("sql", "").strip()
    database= data.get("database", "")
    fmt     = data.get("format", "table")

    if env not in VALID_ENVS:
        return jsonify({"error": f"env 必須為 {list(VALID_ENVS)} 之一"}), 400
    if not sql:
        return jsonify({"error": "sql 不可為空"}), 400

    # PROD 防護：不允許 DROP TABLE / DROP DATABASE（可依需求調整）
    if "prod" in env:
        upper = sql.upper()
        for danger in ("DROP TABLE", "DROP DATABASE", "TRUNCATE"):
            if danger in upper:
                return jsonify({"error": f"PROD 環境禁止執行 {danger}"}), 403

    with jobs_lock:
        if sum(1 for j in jobs.values() if j["status"] == "running") >= MAX_JOBS:
            return jsonify({"error": "目前執行中的 job 已達上限，請稍後再試"}), 429

    job_id = str(uuid.uuid4())[:8]
    with jobs_lock:
        jobs[job_id] = {
            "status":       "queued",
            "env":          env,
            "database":     database,
            "format":       fmt,
            "created_epoch": time.time(),
            "created_at":   datetime.utcnow().isoformat(),
        }

    thread = threading.Thread(target=run_ansible, args=(job_id, env, database, sql, fmt), daemon=True)
    thread.start()

    return jsonify({"job_id": job_id, "status": "queued"}), 202


@app.route("/api/sql/result/<job_id>")
@require_token
def get_result(job_id: str):
    """
    GET /api/sql/result/<job_id>
    輪詢查詢結果，status: queued | running | done | error | timeout
    """
    with jobs_lock:
        job = jobs.get(job_id)
    if not job:
        return jsonify({"error": "job 不存在或已過期"}), 404
    return jsonify(job)


@app.route("/api/sql/ping", methods=["POST"])
@require_token
def ping_all():
    """
    POST /api/sql/ping
    測試所有 TiDB 連線
    """
    job_id = "ping_" + str(uuid.uuid4())[:6]
    with jobs_lock:
        jobs[job_id] = {"status": "queued", "created_epoch": time.time(), "created_at": datetime.utcnow().isoformat()}

    def _run_ping(jid):
        with jobs_lock:
            jobs[jid]["status"] = "running"
        cmd = [str(VENV_ANSIBLE), str(INSTALL_DIR / "playbooks/ping_all.yml")]
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=str(INSTALL_DIR), timeout=60)
        with jobs_lock:
            jobs[jid].update({
                "status":     "done" if result.returncode == 0 else "error",
                "returncode": result.returncode,
                "stdout":     result.stdout,
                "stderr":     result.stderr,
                "finished_at": datetime.utcnow().isoformat(),
            })

    threading.Thread(target=_run_ping, args=(job_id,), daemon=True).start()
    return jsonify({"job_id": job_id, "status": "queued"}), 202


# ─── Main ────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    threading.Thread(target=cleanup_old_jobs, daemon=True).start()
    log.info("API Bridge 啟動，監聽 127.0.0.1:8765")
    app.run(host="127.0.0.1", port=8765, debug=False, threaded=True)
